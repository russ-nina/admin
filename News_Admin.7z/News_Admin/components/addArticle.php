<?php
/**
 * Created by PhpStorm.
 * User: Nina
 * Date: 17.02.2019
 * Time: 13:20
 */

require_once 'functions.php';
$headline = @$_POST["headline"];
$category = @$_POST["category"];
$tag = @$_POST["tag"];
$content = @$_POST["content"];
$author = @$_POST["author"];
$filter_category = @$_POST["filter_category"];

addArticle($headline, $category, $tag, $content, $author, $filter_category);
echo json_encode(getIdArt());



