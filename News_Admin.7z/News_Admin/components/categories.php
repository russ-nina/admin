<?php
/**
 * Created by PhpStorm.
 * User: Nina
 * Date: 19.02.2019
 * Time: 11:41
 */
require_once 'functions.php';
echo json_encode(getAllCategories());