<?php
/**
 * Created by PhpStorm.
 * User: Nina
 * Date: 25.02.2019
 * Time: 16:24
 */
require_once 'functions.php';
echo json_encode(getAllArticles());