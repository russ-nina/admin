<?php
/**
 * Created by PhpStorm.
 * User: Nina
 * Date: 26.09.2018
 * Time: 20:22
 */
require_once 'functions.php';
echo json_encode(getAllPages());