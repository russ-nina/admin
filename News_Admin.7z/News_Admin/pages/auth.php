<?php

?>
<div class="cover_authorization" ">
    <div class="block_authorization">
        <h2 class="title_authorization" style="">Authorization admin</h2>
        <form class="form_authorization" action="./components/auth_user.php" method="post">
            <input class="input_authorization_login" type="text" name="login" placeholder="login">
            <input class="input_authorization_pass" type="text" name="pass" placeholder="password">
            <input class="input_authorization_send" type="submit" name="send" value="Send">
        </form>
<!--        <a href="./?page=registr">Регистрация</a>-->
    </div>
</div>
